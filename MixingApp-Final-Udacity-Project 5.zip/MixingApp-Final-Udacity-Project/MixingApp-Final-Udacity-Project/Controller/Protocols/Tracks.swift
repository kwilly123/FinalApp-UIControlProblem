//
//  Tracks.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import UIKit
import MobileCoreServices
import AVFoundation
import Firebase

extension TracksViewController: Tracks {
    
    func importTrack(cell: TrackCell) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        print(index ?? 0)
        let alert = UIAlertController(title: "Import Track", message: "Would you like to import an audio file into Track \(indexPath!.row + 1)?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (alert: UIAlertAction!) in
            let documentPickerController = UIDocumentPickerViewController(documentTypes: [String(kUTTypeMP3)], in: .import)
            documentPickerController.delegate = self
            self.present(documentPickerController, animated: true)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }
    
    func removeTrack(cell: TrackCell) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        print(index ?? 0)
        let alert = UIAlertController(title: "Remove Track", message: "Would you like to remove an audio file on Track \(indexPath!.row + 1)?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (alert: UIAlertAction!) in
            if let indexPath = indexPath {
                
                let storageRef = Storage.storage().reference().child(self.userID!).child(self.projectKey!).child("audiofiles").child("track\(indexPath.row)").child("audio.mp3") //refactor into network, each child for endpoints
                storageRef.delete { (error) in
                    if error != nil {
                        print("error deleting track")
                        return
                    } else {
                        self.filesArray.remove(at: indexPath.row)
                        self.filesArray.insert(nil, at: indexPath.row)
                        print("Removed Audio Track at \(indexPath.row)")
                        cell.importLight.backgroundColor = .clear
                        cell.buttonRemove.isEnabled = false
                        cell.buttonRemove.alpha = 0.5
                        cell.buttonImport.isEnabled = true
                        cell.buttonImport.alpha = 1.0
                        cell.audioPlayer?.stop()
                    }
                }
            }
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }
    
}
