//
//  Track.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-16.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import Firebase

class Track {
    
    var pan: Float?
    var volume: Float?
    var volumeSlider: Float?
    var mute: Bool?
    var solo: Bool?
    var eq: EQ?

}
